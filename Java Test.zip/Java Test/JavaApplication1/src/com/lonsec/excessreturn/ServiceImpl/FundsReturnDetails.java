/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceImpl;

import com.lonsec.excessreturn.ServiceInterface.FileLookUpInterface;
import com.lonsec.excessreturn.ServiceVO.FundReturnSeriesVO;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Devendra
 */
public class FundsReturnDetails implements FileLookUpInterface {
        
    @Override
    @SuppressWarnings("CallToPrintStackTrace")
    public List fileLookUp(String sFilePath) {
        
        List<FundReturnSeriesVO> lExcessReturnVOList = new ArrayList<>(); 
        
    try
    {
      FileReader fr = new FileReader(sFilePath);
            try (BufferedReader br = new BufferedReader(fr)) {
                String stringRead = br.readLine();
                
                while( stringRead != null )
                {
                    StringTokenizer st = new StringTokenizer(stringRead.replaceAll("^\"|\"$", ""), ",");
                    String sFuncCode = st.nextToken( );
                    String sFuncDate = st.nextToken( );  
                    String sReturn = st.nextToken( ); 
                    
                    FundReturnSeriesVO temp = new FundReturnSeriesVO();
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
                    temp.setFundCode(sFuncCode);
                    temp.setFundDate(LocalDate.parse(sFuncDate,formatter));
                    temp.setFundReturn(Double.parseDouble(sReturn));
                    
                    lExcessReturnVOList.add(temp);
                    
                    // read the next line
                    stringRead = br.readLine();
                }     
            }
    }
    catch(IOException ioe){
            try {
                throw ioe;
            } catch (IOException ex) {
                Logger.getLogger(FundsReturnDetails.class.getName()).log(Level.SEVERE, null, ex);
            }catch (NumberFormatException e) {
                e.printStackTrace();
            }
            
        }
    
        return lExcessReturnVOList;
    
    } 

}
