/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceImpl;

import com.lonsec.excessreturn.ServiceInterface.FileLookUpInterface;
import com.lonsec.excessreturn.ServiceVO.BenchReturnSeriesVO;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Devendra
 */
public class BenchMarkReturnDetails implements FileLookUpInterface{
    
     @Override
     public List fileLookUp(String sFilePath) {
        
        List<BenchReturnSeriesVO> lBenchReturnSeriesList = new ArrayList<>(); 
        
    try
    {
      FileReader fr = new FileReader(sFilePath);
            try (BufferedReader br = new BufferedReader(fr)) {
                String stringRead = br.readLine();
                
                while( stringRead != null )
                {
                    StringTokenizer st = new StringTokenizer(stringRead.replaceAll("^\"|\"$", ""), ",");
                    String sBenchMarkCode = st.nextToken( );
                    String sBenchMarkDate = st.nextToken( );  
                    String sReturn = st.nextToken( ); 
                    
                    BenchReturnSeriesVO temp = new BenchReturnSeriesVO();
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
                    temp.setBenchMarkCode(sBenchMarkCode);
                    temp.setBenchMarkReturnDate(LocalDate.parse(sBenchMarkDate,formatter));
                    temp.setBenchMarkReturnValue(Double.parseDouble(sReturn));
                    
                    lBenchReturnSeriesList.add(temp);
                    
                    // read the next line
                    stringRead = br.readLine();
                }     
            }
    }
    catch(IOException ioe){
            try {
                throw ioe;
            } catch (IOException ex) {
                Logger.getLogger(BenchMarkReturnDetails.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        return lBenchReturnSeriesList;
    }   
}
