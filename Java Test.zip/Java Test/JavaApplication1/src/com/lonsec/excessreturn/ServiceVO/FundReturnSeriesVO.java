/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceVO;

import java.time.LocalDate;


/*************************************************************************
 * This value object is used to store Excess Return Details.
 * @author	: Devendra Rane
 * @version	: 
 * @creation date    : February 07, 2017
 * @since	: Lonsec Excess Return Module
 ***************************************************************************/
public class FundReturnSeriesVO implements java.io.Serializable {
        
	private String sFundCode;
	private LocalDate tFundDate;
	private double dFundReturn;
        

	public FundReturnSeriesVO()
	{
		super();
	}

	public void setFundCode(String iFundCode)
	{
		this.sFundCode=iFundCode;
	}

	public String getFundCode()
	{
		return sFundCode;
	}

	public void setFundDate(LocalDate iFundDate)
	{
		this.tFundDate=iFundDate;
	}

	public LocalDate getFundDate()
	{
		return tFundDate;
	}
	public void setFundReturn(double iFundReturn)
	{
		this.dFundReturn=iFundReturn;
	}

	public double getFundReturn()
	{
		return dFundReturn;
	}
	  
}

