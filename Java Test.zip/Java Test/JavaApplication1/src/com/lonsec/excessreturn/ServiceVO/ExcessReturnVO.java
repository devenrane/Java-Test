/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceVO;

import java.time.LocalDate;


/*************************************************************************
 * This value object is used to store Excess Return Details.
 * @author	: Devendra Rane
 * @version	: 
 * @creation date    : February 07, 2017
 * @since	: Lonsec Excess Return Module
 ***************************************************************************/
public class ExcessReturnVO implements java.io.Serializable {
        
	private String sFundCode;
	private String sFundName;
        private LocalDate tFundDate;
	private double dFundReturn;
        private String sBenchMarkCode;
	private String sBenchMarkName;
	private LocalDate tBenchMarkDate;
	private double sBenchMarkReturn;
	private double sExcess;
	private String sOutPerformance;
	private int sRank;

	public ExcessReturnVO()
	{
		super();
	}

	public void setFundCode(String iFundCode)
	{
		this.sFundCode=iFundCode;
	}

	public String getFundCode()
	{
		return sFundCode;
	}

	public void setFundName(String iFundName)
	{
		this.sFundName=iFundName;
	}

	public String getFundName()
	{
		return sFundName;
	}
	public void setFundDate(LocalDate iFundDate)
	{
		this.tFundDate=iFundDate;
	}

	public LocalDate getFundDate()
	{
		return tFundDate;
	}
	public void setFundReturn(double iFundReturn)
	{
		this.dFundReturn=iFundReturn;
	}

	public double getFundReturn()
	{
		return dFundReturn;
	}
	public void setBenchMarkCode(String iBenchMarkCode)
	{
		this.sBenchMarkCode=iBenchMarkCode;
	}

	public String getBenchMarkCode()
	{
		return sBenchMarkCode;
	}
	public void setBenchMarkName(String iBenchMarkName)
	{
		this.sBenchMarkName = iBenchMarkName;
	}

	public String getBenchMarkName()
	{
		return sBenchMarkName;
	}
	public void setBenchMarkDate(LocalDate iBenchMarkDate)
	{
		this.tBenchMarkDate=iBenchMarkDate;
	}

	public LocalDate getBenchMarkDate()
	{
		return tBenchMarkDate;
	}
	public void setBenchMarkReturn(double iBenchMarkReturn)
	{
		this.sBenchMarkReturn=iBenchMarkReturn;
	}

	public double getBenchMarkReturn()
	{
		return sBenchMarkReturn;
	}
	public void setExcess(double iExcess)
	{
		this.sExcess=iExcess;
	}

	public double getExcess()
	{
		return sExcess;
	}
	public void setOutPerformance(String iOutPerformance)
	{
		this.sOutPerformance=iOutPerformance;
	}

	public String getOutPerformance()
	{
		return sOutPerformance;
	}
	public void setRank(int iRank)
	{
		this.sRank=iRank;
	}

	public int getRank()
	{
		return sRank;
	}
  
}

