/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceVO;

import java.time.LocalDate;

/*************************************************************************
 * This value object is used to store Excess Return Details.
 * @author	: Devendra Rane
 * @version	: 
 * @creation date    : February 07, 2017
 * @since	: Lonsec Excess Return Module
 ***************************************************************************/
public class BenchReturnSeriesVO implements java.io.Serializable {
        
        private String sBMCode;
        private LocalDate dBMReturnDate;
        private double dBMReturn;
	

	public BenchReturnSeriesVO()
	{
		super();
	}

	public void setBenchMarkCode(String iBenchMarkCode)
	{
		this.sBMCode=iBenchMarkCode;
	}

	public String getBenchMarkCode()
	{
		return sBMCode;
	}
        
       public void setBenchMarkReturnDate(LocalDate iBenchMarkDate)
	{
		this.dBMReturnDate = iBenchMarkDate;
	}

	public LocalDate getBenchMarkReturnDate()
	{
		return dBMReturnDate;
	}
        public void setBenchMarkReturnValue(double iBenchMarkReturn)
	{
		this.dBMReturn = iBenchMarkReturn;
	}

	public double getBenchMarkReturnValue()
	{
		return dBMReturn;
	}
	  
}

