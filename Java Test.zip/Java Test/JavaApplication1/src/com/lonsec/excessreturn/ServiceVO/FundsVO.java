/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceVO;


/*************************************************************************
 * This value object is used to store Excess Return Details.
 * @author	: Devendra Rane
 * @version	: 
 * @creation date    : February 07, 2017
 * @since	: Lonsec Excess Return Module
 ***************************************************************************/
public class FundsVO implements java.io.Serializable {
        
	private String sFundCode;
	private String sFundName;
        private String sBenchMarkCode;
	

	public FundsVO()
	{
		super();
	}

	public void setFundCode(String iFundCode)
	{
		this.sFundCode=iFundCode;
	}

	public String getFundCode()
	{
		return sFundCode;
	}

	public void setFundName(String iFundName)
	{
		this.sFundName=iFundName;
	}

	public String getFundName()
	{
		return sFundName;
	}
        
        public void setBenchMarkCode(String iBenchMarkCode)
	{
		this.sBenchMarkCode=iBenchMarkCode;
	}

	public String getBenchMarkCode()
	{
		return sBenchMarkCode;
	}
	  
}

