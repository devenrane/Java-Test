/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceConstants;

/**
 * This file holds the constants for the file path and file type for the factory class.
 * 
 * @author Devendra
 */
public class GeneralConstants {
    
    public static final String FUNDS_EXCESS_FILE = "FUNDS_EXCESS_FILE";

    public static final String BENCHMARK_EXCESS_FILE = "BENCHMARK_EXCESS_FILE";

    public static final String FUNDS_DETAIL_FILE = "FUNDS_DETAIL_FILE";
    
    public static final String BENCHMARK_DETAIL_FILE = "BENCHMARK_DETAIL_FILE";
    
    
    /* Update the below constants with the file paths */
    
    public static final String FUNDS_EXCESS_FILE_PATH = "C:\\Lonsec\\InputFiles\\fundReturnSeries.csv";

    public static final String BENCHMARK_EXCESS_FILE_PATH = "C:\\Lonsec\\InputFiles\\benchReturnSeries.csv";

    public static final String FUNDS_DETAIL_FILE_PATH = "C:\\Lonsec\\InputFiles\\funds.csv";
    
    public static final String BENCHMARK_DETAIL_FILE_PATH = "C:\\Lonsec\\InputFiles\\benchmark.csv";
    
    public static final String OUTPUT_RETURN_EXCESS_FILE_PATH = "C:\\Lonsec\\OutputFiles\\outperformance.csv";
    
    //Delimiter used in CSV file

    public static final String COMMA_DELIMITER = ",";

    public static final String NEW_LINE_SEPARATOR = "\n";
    
    public static final String BLANK_STATUS = "<<BLANK>>";
    
    public static final String OUT_PERFORMED_STATUS = "Out Performed";
    
    public static final String UNDER_PERFORMED_STATUS = "Under Performed";
    
    
    	     
}
