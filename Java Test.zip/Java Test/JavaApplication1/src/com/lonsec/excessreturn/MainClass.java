/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn;
import com.lonsec.excessreturn.Service.ExcessReturnService;


/**
 *
 * @author Devendra
 */
public class MainClass
{

  public static void main(String [] args)
  {
    /* Call to the service which reads input files and produces the out performance report.*/  
    ExcessReturnService s = new ExcessReturnService();
    s.callService();
  
  }
}
