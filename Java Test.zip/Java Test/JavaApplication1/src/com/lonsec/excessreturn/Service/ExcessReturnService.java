/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.Service;

import com.lonsec.excessreturn.ServiceFactory.FileTypeFactory;
import com.lonsec.excessreturn.ServiceConstants.GeneralConstants;
import com.lonsec.excessreturn.ServiceInterface.FileLookUpInterface;
import com.lonsec.excessreturn.ServiceVO.BenchReturnSeriesVO;
import com.lonsec.excessreturn.ServiceVO.ExcessReturnVO;
import com.lonsec.excessreturn.ServiceVO.FundReturnSeriesVO;
import com.lonsec.excessreturn.ServiceVO.FundsVO;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**.
 *
 * @author Devendra
 */
public class ExcessReturnService {
    
    public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) 
    {
        Map<Object, Boolean> map = new ConcurrentHashMap<>();
        return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    } 
    
    public void callService(){
    
        List<FundReturnSeriesVO> lFundExcessReturnList = getDetails(GeneralConstants.FUNDS_EXCESS_FILE);
    
            if((null!=lFundExcessReturnList)){
        
                List<FundReturnSeriesVO> listDistinctElements = lFundExcessReturnList.stream().filter(distinctByKey(p -> p.getFundDate())).collect(Collectors.toList());
    
                listDistinctElements.sort((o1, o2) -> {
        
                int cmp = o2.getFundDate().compareTo(o1.getFundDate());
    
                return cmp;
            });

            int nDisObj = listDistinctElements.size();
            int nFundObj = lFundExcessReturnList.size();
    
                for(int i=0; i<nDisObj; i++){

                    FundReturnSeriesVO frDisVO = listDistinctElements.get(i);

                    List<ExcessReturnVO> lExcessReturnList = new ArrayList<>();  

                        for(int j=0; j<nFundObj; j++){

                            FundReturnSeriesVO frVO = lFundExcessReturnList.get(j);

                            if(frDisVO.getFundDate().equals(frVO.getFundDate())){

                                ExcessReturnVO erVO = new ExcessReturnVO();
                                erVO.setFundCode(frVO.getFundCode());
                                erVO.setFundDate(frVO.getFundDate());
                                erVO.setFundReturn(frVO.getFundReturn());

                                lExcessReturnList.add(erVO);

                            }

                        }

                    lExcessReturnList = setRank(lExcessReturnList);

                    lExcessReturnList = setFundDetails(lExcessReturnList); 

                    lExcessReturnList = setBenchMarkDetails(lExcessReturnList); 

                    printMonthlyOutPerf(lExcessReturnList,i,nDisObj);

                }            
            }
    }       
     
    private List getDetails(String sFileType){
        
        HashMap mFilePathMap = new HashMap();
    
        mFilePathMap.put(GeneralConstants.BENCHMARK_DETAIL_FILE,GeneralConstants.BENCHMARK_DETAIL_FILE_PATH);
        mFilePathMap.put(GeneralConstants.BENCHMARK_EXCESS_FILE,GeneralConstants.BENCHMARK_EXCESS_FILE_PATH);
        mFilePathMap.put(GeneralConstants.FUNDS_DETAIL_FILE,GeneralConstants.FUNDS_DETAIL_FILE_PATH);
        mFilePathMap.put(GeneralConstants.FUNDS_EXCESS_FILE,GeneralConstants.FUNDS_EXCESS_FILE_PATH);
       
            FileTypeFactory factoryObj = new FileTypeFactory();
    
                FileLookUpInterface lExcessReturn = factoryObj.getFileDetails(sFileType);
    
                    List list = lExcessReturn.fileLookUp(mFilePathMap.get(sFileType).toString());
    
                return list;
    
    } 
    
    private List setRank(List lEReturnList){
        
        List<ExcessReturnVO> listRankReturn = lEReturnList;
        
            listRankReturn.sort((o1, o2) -> {
        
            int cmp = o2.getFundDate().compareTo(o1.getFundDate());
    
            if (cmp == 0)
            cmp = Double.compare(o2.getFundReturn(), o1.getFundReturn());
    
        return cmp;
            
            });
     
     
        int nObjects = listRankReturn.size();
     
        for(int x =0;x<nObjects;x++){
           
           ExcessReturnVO erVO = listRankReturn.get(x);
           erVO.setRank(x+1);          
        }            
        
        return listRankReturn;
    }
    
    private List setFundDetails(List lEReturnList){
           
        List<ExcessReturnVO> listFundReturn = lEReturnList;
           
        List<FundsVO> lFundsVOList = getDetails(GeneralConstants.FUNDS_DETAIL_FILE);
           
            int iRListSize = lEReturnList.size();
            int iFListSize = lFundsVOList.size();
           
            for(int a=0; a<iRListSize; a++){
           
                ExcessReturnVO eReturnVO = listFundReturn.get(a);
           
                for(int j=0; j<iFListSize; j++){
              
                    FundsVO fundVO = lFundsVOList.get(j);
           
                        if(eReturnVO.getFundCode().equals(fundVO.getFundCode())){
               
                            eReturnVO.setFundName(fundVO.getFundName());
                            eReturnVO.setBenchMarkCode(fundVO.getBenchMarkCode());
                        
                        }
                }
            }
            
        return lEReturnList;
    }
       
    private List setBenchMarkDetails(List lEReturnList){
           
        List<ExcessReturnVO> listFundReturn = lEReturnList;
           
        List<BenchReturnSeriesVO> lBenchReturnSeriesList = getDetails(GeneralConstants.BENCHMARK_EXCESS_FILE);
           
            int iRListSize = lEReturnList.size();
            int iBListSize = lBenchReturnSeriesList.size();
           
            for(int k=0; k<iRListSize; k++){
           
                ExcessReturnVO eReturnVO = listFundReturn.get(k);
           
                for(int j=0; j<iBListSize; j++){
              
                    BenchReturnSeriesVO BRSeriesVO = lBenchReturnSeriesList.get(j);
           
                        if((eReturnVO.getBenchMarkCode().equals(BRSeriesVO.getBenchMarkCode()))&&(eReturnVO.getFundDate().equals(BRSeriesVO.getBenchMarkReturnDate()))){
                           eReturnVO.setBenchMarkReturn(BRSeriesVO.getBenchMarkReturnValue());
                           eReturnVO.setExcess(eReturnVO.getFundReturn()-BRSeriesVO.getBenchMarkReturnValue());
                        }
           
                        eReturnVO.setOutPerformance (((eReturnVO.getExcess()>1.0)? GeneralConstants.OUT_PERFORMED_STATUS:((eReturnVO.getExcess()<-1.0)? GeneralConstants.UNDER_PERFORMED_STATUS:GeneralConstants.BLANK_STATUS)));                         
                        
                        
                }
            }
            
        return lEReturnList;
    }
       
    public void printMonthlyOutPerf(List lEReturnList, int i, int j) {
           
        FileWriter fileWriter = null;

	    try {
               
                if (i==0){
                    
	            fileWriter = new FileWriter(GeneralConstants.OUTPUT_RETURN_EXCESS_FILE_PATH);
                    
                }else{
                    
                    fileWriter = new FileWriter(GeneralConstants.OUTPUT_RETURN_EXCESS_FILE_PATH,true);
                
                }

                    //Write a outperformance objects list to the CSV file
	            List<ExcessReturnVO> listFundReturn = lEReturnList;
                    
	            for (ExcessReturnVO excessObj : listFundReturn) {

	                fileWriter.append(String.valueOf(excessObj.getFundName()));

	                fileWriter.append(GeneralConstants.COMMA_DELIMITER);

                        fileWriter.append(excessObj.getFundDate().toString());

                        fileWriter.append(GeneralConstants.COMMA_DELIMITER);
                
                        DecimalFormat dformat = new DecimalFormat("##.00");
                
                        fileWriter.append(dformat.format(excessObj.getExcess()));

	                fileWriter.append(GeneralConstants.COMMA_DELIMITER);

	                fileWriter.append(excessObj.getOutPerformance());

	                fileWriter.append(GeneralConstants.COMMA_DELIMITER);

	                fileWriter.append(dformat.format(excessObj.getFundReturn()));
                        
                        fileWriter.append(GeneralConstants.COMMA_DELIMITER);

	                fileWriter.append(Integer.toString(excessObj.getRank()));
                      
	                fileWriter.append(GeneralConstants.NEW_LINE_SEPARATOR);

                    }    
	 
                System.out.println("CSV file was created successfully !!!");

	    } catch (Exception e) {

	            System.out.println("Error in CsvFileWriter !!!");

	            e.printStackTrace();

	    } finally {

	            try {

	                fileWriter.flush();

	                fileWriter.close();

	            } catch (IOException e) {

	                System.out.println("Error while flushing/closing fileWriter !!!");

	                e.printStackTrace();

	            }
	        }
	    }
    }

