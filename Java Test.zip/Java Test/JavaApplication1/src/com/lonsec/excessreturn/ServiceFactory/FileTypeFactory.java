/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceFactory;

import com.lonsec.excessreturn.ServiceImpl.BenchMarkDetails;
import com.lonsec.excessreturn.ServiceImpl.BenchMarkReturnDetails;
import com.lonsec.excessreturn.ServiceImpl.FundDetails;
import com.lonsec.excessreturn.ServiceImpl.FundsReturnDetails;
import com.lonsec.excessreturn.ServiceInterface.FileLookUpInterface;

/**
 * This class is a factory class to retrieve the correct class for the implementation of the file reading class.
 * 
 * @author Devendra
 */
public class FileTypeFactory {
	
    //use getFileDetails method to get object of type FileLookUpInterface 
    public FileLookUpInterface getFileDetails(String fileType){
        if(fileType == null){
           return null;
        }		
        if(fileType.equalsIgnoreCase("FUNDS_EXCESS_FILE")){
           return new FundsReturnDetails();

        } else if(fileType.equalsIgnoreCase("BENCHMARK_EXCESS_FILE")){
           return new BenchMarkReturnDetails();

        } else if(fileType.equalsIgnoreCase("FUNDS_DETAIL_FILE")){
           return new FundDetails();

        } else if(fileType.equalsIgnoreCase("BENCHMARK_DETAIL_FILE")){
           return new BenchMarkDetails();
        }
        
        return null;
    }
}