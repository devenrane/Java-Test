/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceInterface;

import com.lonsec.excessreturn.ServiceVO.FundReturnSeriesVO;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Devendra
 */
public class FileLookUpInterfaceTest {
    
    public FileLookUpInterfaceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of fileLookUp method, of class FileLookUpInterface.
     */
    @Test
    public void testFileLookUp() {
        System.out.println("fileLookUp");
        String s = "FILE_PATH";
        FileLookUpInterface instance = new FileLookUpInterfaceImpl();
        
        List<FundReturnSeriesVO> expResult = new ArrayList<>();
        List result = instance.fileLookUp(s);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    public class FileLookUpInterfaceImpl implements FileLookUpInterface {

        public List fileLookUp(String s) {
            List<FundReturnSeriesVO> lFundVO = new ArrayList<>();
            return lFundVO;
        }
    }
    
}
