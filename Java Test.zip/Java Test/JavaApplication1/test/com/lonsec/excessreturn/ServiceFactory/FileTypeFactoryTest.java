/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceFactory;

import com.lonsec.excessreturn.ServiceImpl.FundsReturnDetails;
import com.lonsec.excessreturn.ServiceInterface.FileLookUpInterface;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Devendra
 */
public class FileTypeFactoryTest {
    
    public FileTypeFactoryTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getFileDetails method, of class FileTypeFactory.
     */
    @Test
    public void testGetFileDetails() {
        System.out.println("getFileDetails");
        String fileType = "FUNDS_EXCESS_FILE";
        FileTypeFactory instance = new FileTypeFactory();
            
         
        FundsReturnDetails instancefund =  new FundsReturnDetails();
        FileLookUpInterface expResult = instancefund;
        FileLookUpInterface result = instance.getFileDetails(fileType);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
}
