/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceImpl;

import com.lonsec.excessreturn.ServiceVO.FundReturnSeriesVO;
import com.lonsec.excessreturn.ServiceVO.FundsVO;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Devendra
 */
public class FundDetailsTest {
    
    public FundDetailsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of fileLookUp method, of class FundDetails.
     */
    @Test
    public void testFileLookUp() {
        System.out.println("fileLookUp");
        String sFilePath = "FUNDS_DETAIL_FILE";
        FundDetails instance = new FundDetails();
        //List expResult = null;
        List<FundsVO> expResult = new ArrayList<>();
        List result = instance.fileLookUp(sFilePath);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
