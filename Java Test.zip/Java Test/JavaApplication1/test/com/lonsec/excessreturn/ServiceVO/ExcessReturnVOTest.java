/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceVO;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Devendra
 */
public class ExcessReturnVOTest {
    
    public ExcessReturnVOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setFundCode method, of class ExcessReturnVO.
     */
    @Test
    public void testSetFundCode() {
        System.out.println("setFundCode");
        String iFundCode = "fund1";
        String expResult = "fund1";
        ExcessReturnVO instance = new ExcessReturnVO();
        instance.setFundCode(iFundCode);
        String result = instance.getFundCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFundCode method, of class ExcessReturnVO.
     */
    @Test
    public void testGetFundCode() {
        System.out.println("getFundCode");
        ExcessReturnVO instance = new ExcessReturnVO();
        String expResult = "fund1";
        instance.setFundCode(expResult);
        String result = instance.getFundCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setFundName method, of class ExcessReturnVO.
     */
    @Test
    public void testSetFundName() {
        System.out.println("setFundName");
        String iFundName = "fundname1";
        String expResult = iFundName;
        ExcessReturnVO instance = new ExcessReturnVO();
        instance.setFundName(iFundName);
        String result = instance.getFundName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFundName method, of class ExcessReturnVO.
     */
    @Test
    public void testGetFundName() {
        System.out.println("getFundName");
        ExcessReturnVO instance = new ExcessReturnVO();
        String expResult = "fundname1";
        instance.setFundName(expResult);
        String result = instance.getFundName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setFundDate method, of class ExcessReturnVO.
     */
    @Test
    public void testSetFundDate() {
        System.out.println("setFundDate");
        String sDate = "30/06/2016";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate iFundDate = LocalDate.parse(sDate,formatter);
        LocalDate expResult = LocalDate.parse("30/06/2016",formatter);
        ExcessReturnVO instance = new ExcessReturnVO();
        instance.setFundDate(iFundDate);
        LocalDate result = instance.getFundDate();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFundDate method, of class ExcessReturnVO.
     */
    @Test
    public void testGetFundDate() {
        System.out.println("getFundDate");
        ExcessReturnVO instance = new ExcessReturnVO();
        String sDate = "30/06/2016";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate iFundDate = LocalDate.parse(sDate,formatter);
        LocalDate expResult = LocalDate.parse("30/06/2016",formatter);
        instance.setFundDate(iFundDate);
        LocalDate result = instance.getFundDate();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setFundReturn method, of class ExcessReturnVO.
     */
    @Test
    public void testSetFundReturn() {
        System.out.println("setFundReturn");
        double iFundReturn = 9.9;
        double expResult = 9.9;
        ExcessReturnVO instance = new ExcessReturnVO();
        instance.setFundReturn(iFundReturn);
        double result = instance.getFundReturn();
        assertEquals(expResult, result, 9.9);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFundReturn method, of class ExcessReturnVO.
     */
    @Test
    public void testGetFundReturn() {
        System.out.println("getFundReturn");
        ExcessReturnVO instance = new ExcessReturnVO();
        double expResult = 0.0;
        instance.setFundReturn(expResult);
        double result = instance.getFundReturn();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setBenchMarkCode method, of class ExcessReturnVO.
     */
    @Test
    public void testSetBenchMarkCode() {
        System.out.println("setBenchMarkCode");
        String iBenchMarkCode = "bm1";
        String expResult = "bm1";
        ExcessReturnVO instance = new ExcessReturnVO();
        instance.setBenchMarkCode(iBenchMarkCode);
        String result = instance.getBenchMarkCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getBenchMarkCode method, of class ExcessReturnVO.
     */
    @Test
    public void testGetBenchMarkCode() {
        System.out.println("getBenchMarkCode");
        ExcessReturnVO instance = new ExcessReturnVO();
        String expResult = "bm1";
        instance.setBenchMarkCode(expResult);
        String result = instance.getBenchMarkCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setBenchMarkName method, of class ExcessReturnVO.
     */
    @Test
    public void testSetBenchMarkName() {
        System.out.println("setBenchMarkName");
        String iBenchMarkName = "bmName1";
        String expResult = "bmName1";
        ExcessReturnVO instance = new ExcessReturnVO();
        instance.setBenchMarkName(iBenchMarkName);
        String result = instance.getBenchMarkName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getBenchMarkName method, of class ExcessReturnVO.
     */
    @Test
    public void testGetBenchMarkName() {
        System.out.println("getBenchMarkName");
        ExcessReturnVO instance = new ExcessReturnVO();
        String expResult = "bmname1";
        instance.setBenchMarkName(expResult);
        String result = instance.getBenchMarkName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setBenchMarkDate method, of class ExcessReturnVO.
     */
    @Test
    public void testSetBenchMarkDate() {
        System.out.println("setBenchMarkDate");
        String sDate = "30/06/2016";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate iBenchMarkDate = LocalDate.parse(sDate,formatter);
        LocalDate expResult = LocalDate.parse("30/06/2016",formatter);
        ExcessReturnVO instance = new ExcessReturnVO();
        instance.setBenchMarkDate(iBenchMarkDate);
        LocalDate result = instance.getBenchMarkDate();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getBenchMarkDate method, of class ExcessReturnVO.
     */
    @Test
    public void testGetBenchMarkDate() {
        System.out.println("getBenchMarkDate");
        ExcessReturnVO instance = new ExcessReturnVO();
        String sDate = "30/06/2016";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate tDate = LocalDate.parse(sDate,formatter);
        instance.setBenchMarkDate(tDate);
        LocalDate expResult = tDate;
        LocalDate result = instance.getBenchMarkDate();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setBenchMarkReturn method, of class ExcessReturnVO.
     */
    @Test
    public void testSetBenchMarkReturn() {
        System.out.println("setBenchMarkReturn");
        double iBenchMarkReturn = -8.8;
        double expResult = -8.8;
        ExcessReturnVO instance = new ExcessReturnVO();
        instance.setBenchMarkReturn(iBenchMarkReturn);
        double result = instance.getBenchMarkReturn();
        assertEquals(expResult, result, -8.8);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getBenchMarkReturn method, of class ExcessReturnVO.
     */
    @Test
    public void testGetBenchMarkReturn() {
        System.out.println("getBenchMarkReturn");
        ExcessReturnVO instance = new ExcessReturnVO();
        double expResult = 10.0;
        instance.setBenchMarkReturn(expResult);
        double result = instance.getBenchMarkReturn();
        assertEquals(expResult, result, 10.0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setExcess method, of class ExcessReturnVO.
     */
    @Test
    public void testSetExcess() {
        System.out.println("setExcess");
        double iExcess = 1.67;
        double expResult = 1.67;
        ExcessReturnVO instance = new ExcessReturnVO();
        instance.setExcess(iExcess);
        double result = instance.getExcess();
        assertEquals(expResult, result, 1.67);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getExcess method, of class ExcessReturnVO.
     */
    @Test
    public void testGetExcess() {
        System.out.println("getExcess");
        ExcessReturnVO instance = new ExcessReturnVO();
        double expResult = -6.456;
        double dExcess = -6.456;
        instance.setExcess(dExcess); 
        double result = instance.getExcess();
        assertEquals(expResult, result, -6.456);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setOutPerformance method, of class ExcessReturnVO.
     */
    @Test
    public void testSetOutPerformance() {
        System.out.println("setOutPerformance");
        String iOutPerformance = "outperformance";
        String expResult = "outperformance";
        ExcessReturnVO instance = new ExcessReturnVO();
        instance.setOutPerformance(iOutPerformance);
        String result = instance.getOutPerformance();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getOutPerformance method, of class ExcessReturnVO.
     */
    @Test
    public void testGetOutPerformance() {
        System.out.println("getOutPerformance");
        ExcessReturnVO instance = new ExcessReturnVO();
        String expResult = "outperformance";
        String sOutPerf = "outperformance";
        instance.setOutPerformance(sOutPerf);
        String result = instance.getOutPerformance();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setRank method, of class ExcessReturnVO.
     */
    @Test
    public void testSetRank() {
        System.out.println("setRank");
        int iRank = 8;
        int expResult = 8;
        ExcessReturnVO instance = new ExcessReturnVO();
        instance.setRank(iRank);
        int result = instance.getRank();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getRank method, of class ExcessReturnVO.
     */
    @Test
    public void testGetRank() {
        System.out.println("getRank");
        ExcessReturnVO instance = new ExcessReturnVO();
        int expResult = 9;
        int iRank = 9;
        instance.setRank(iRank);
        int result = instance.getRank();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
