/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceVO;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Devendra
 */
public class FundReturnSeriesVOTest {
    
    public FundReturnSeriesVOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setFundCode method, of class FundReturnSeriesVO.
     */
    @Test
    public void testSetFundCode() {
        System.out.println("setFundCode");
        String iFundCode = "fund1";
        String expResult = "fund1";
        FundReturnSeriesVO instance = new FundReturnSeriesVO();
        instance.setFundCode(iFundCode);
        String result = instance.getFundCode(); 
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFundCode method, of class FundReturnSeriesVO.
     */
    @Test
    public void testGetFundCode() {
        System.out.println("getFundCode");
        FundReturnSeriesVO instance = new FundReturnSeriesVO();
        String expResult = "fund4";
        String sFundCode = "fund4";
        instance.setFundCode(sFundCode);
        String result = instance.getFundCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setFundDate method, of class FundReturnSeriesVO.
     */
    @Test
    public void testSetFundDate() {
        System.out.println("setFundDate");
        String sDate = "30/06/2016";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate iFundDate = LocalDate.parse(sDate,formatter);
        LocalDate expResult = LocalDate.parse("30/06/2016",formatter);
        FundReturnSeriesVO instance = new FundReturnSeriesVO();
        instance.setFundDate(iFundDate);
        LocalDate result = instance.getFundDate();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFundDate method, of class FundReturnSeriesVO.
     */
    @Test
    public void testGetFundDate() {
        System.out.println("getFundDate");
        FundReturnSeriesVO instance = new FundReturnSeriesVO();
        String sDate = "30/06/2016";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate iFundDate = LocalDate.parse(sDate,formatter);
        LocalDate expResult = LocalDate.parse("30/06/2016",formatter);
        instance.setFundDate(iFundDate);
        LocalDate result = instance.getFundDate();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setFundReturn method, of class FundReturnSeriesVO.
     */
    @Test
    public void testSetFundReturn() {
        System.out.println("setFundReturn");
        double iFundReturn = 2.450;
        double expResult = 2.450;
        FundReturnSeriesVO instance = new FundReturnSeriesVO();
        instance.setFundReturn(iFundReturn);
        double result = instance.getFundReturn();
        assertEquals(expResult, result, 2.450);        
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFundReturn method, of class FundReturnSeriesVO.
     */
    @Test
    public void testGetFundReturn() {
        System.out.println("getFundReturn");
        FundReturnSeriesVO instance = new FundReturnSeriesVO();
        double expResult = 1.23;
        double dFundReturn = 1.23;
        instance.setFundReturn(dFundReturn);
        double result = instance.getFundReturn();
        assertEquals(expResult, result, 1.23);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
