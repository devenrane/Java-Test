/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceVO;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Devendra
 */
public class FundsVOTest {
    
    public FundsVOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setFundCode method, of class FundsVO.
     */
    @Test
    public void testSetFundCode() {
        System.out.println("setFundCode");
        String iFundCode = "fund6";
        String expResult = "fund6";
        FundsVO instance = new FundsVO();
        instance.setFundCode(iFundCode);
        String result = instance.getFundCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFundCode method, of class FundsVO.
     */
    @Test
    public void testGetFundCode() {
        System.out.println("getFundCode");
        FundsVO instance = new FundsVO();
        String expResult = "fund5";
        String sFundCode = "fund5";
        instance.setFundCode(sFundCode);
        String result = instance.getFundCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setFundName method, of class FundsVO.
     */
    @Test
    public void testSetFundName() {
        System.out.println("setFundName");
        String iFundName = "FundName1";
        String expResult = "FundName1";
        FundsVO instance = new FundsVO();
        instance.setFundName(iFundName);
        String result = instance.getFundName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFundName method, of class FundsVO.
     */
    @Test
    public void testGetFundName() {
        System.out.println("getFundName");
        FundsVO instance = new FundsVO();
        String expResult = "FundName2";
        String sFundName = "FundName2";
        instance.setFundName(sFundName);
        String result = instance.getFundName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setBenchMarkCode method, of class FundsVO.
     */
    @Test
    public void testSetBenchMarkCode() {
        System.out.println("setBenchMarkCode");
        String iBenchMarkCode = "bm7";
        String expResult = "bm7";
        FundsVO instance = new FundsVO();
        instance.setBenchMarkCode(iBenchMarkCode);
        String result = instance.getBenchMarkCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getBenchMarkCode method, of class FundsVO.
     */
    @Test
    public void testGetBenchMarkCode() {
        System.out.println("getBenchMarkCode");
        FundsVO instance = new FundsVO();
        String expResult = "bm8";
        String sBMCode = "bm8";
        instance.setBenchMarkCode(sBMCode);
        String result = instance.getBenchMarkCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
