/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceVO;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Devendra
 */
public class BenchReturnSeriesVOTest {
    
    public BenchReturnSeriesVOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setBenchMarkCode method, of class BenchReturnSeriesVO.
     */
    @Test
    public void testSetBenchMarkCode() {
        System.out.println("setBenchMarkCode");
        String iBenchMarkCode = "bm3";
        String expResult = "bm3";
        BenchReturnSeriesVO instance = new BenchReturnSeriesVO();
        instance.setBenchMarkCode(iBenchMarkCode);
        String result = instance.getBenchMarkCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getBenchMarkCode method, of class BenchReturnSeriesVO.
     */
    @Test
    public void testGetBenchMarkCode() {
        System.out.println("getBenchMarkCode");
        BenchReturnSeriesVO instance = new BenchReturnSeriesVO();
        String expResult = "bm6";
        String sBMCode = "bm6";
        instance.setBenchMarkCode(sBMCode);
        String result = instance.getBenchMarkCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setBenchMarkReturnDate method, of class BenchReturnSeriesVO.
     */
    @Test
    public void testSetBenchMarkReturnDate() {
        System.out.println("setBenchMarkReturnDate");
        String sDate = "31/07/2016";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate iBMDate = LocalDate.parse(sDate,formatter);
        LocalDate expResult = LocalDate.parse("31/07/2016",formatter);
        BenchReturnSeriesVO instance = new BenchReturnSeriesVO();
        instance.setBenchMarkReturnDate(iBMDate);
        LocalDate result = instance.getBenchMarkReturnDate();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getBenchMarkReturnDate method, of class BenchReturnSeriesVO.
     */
    @Test
    public void testGetBenchMarkReturnDate() {
        System.out.println("getBenchMarkReturnDate");
        BenchReturnSeriesVO instance = new BenchReturnSeriesVO();
        String sDate = "31/07/2016";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate iBMDate = LocalDate.parse(sDate,formatter);
        LocalDate expResult = LocalDate.parse("31/07/2016",formatter);
        instance.setBenchMarkReturnDate(iBMDate);
        LocalDate result = instance.getBenchMarkReturnDate();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setBenchMarkReturnValue method, of class BenchReturnSeriesVO.
     */
    @Test
    public void testSetBenchMarkReturnValue() {
        System.out.println("setBenchMarkReturnValue");
        double iBenchMarkReturn = 9.456;
        double expResult = 9.456;
        BenchReturnSeriesVO instance = new BenchReturnSeriesVO();
        instance.setBenchMarkReturnValue(iBenchMarkReturn);
        double result = instance.getBenchMarkReturnValue();
        assertEquals(expResult, result, 9.456);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getBenchMarkReturnValue method, of class BenchReturnSeriesVO.
     */
    @Test
    public void testGetBenchMarkReturnValue() {
        System.out.println("getBenchMarkReturnValue");
        BenchReturnSeriesVO instance = new BenchReturnSeriesVO();
        double expResult = -1.204;
        double dBMRValue = -1.204;
        instance.setBenchMarkReturnValue(dBMRValue);
        double result = instance.getBenchMarkReturnValue();
        assertEquals(expResult, result, -1.204);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
