/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.ServiceVO;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Devendra
 */
public class BenchMarkVOTest {
    
    public BenchMarkVOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setBenchMarkName method, of class BenchMarkVO.
     */
    @Test
    public void testSetBenchMarkName() {
        System.out.println("setBenchMarkName");
        String iBenchMarkName = "BMName5";
        String expResult = "BMName5";
        BenchMarkVO instance = new BenchMarkVO();
        instance.setBenchMarkName(iBenchMarkName);
        String result = instance.getBenchMarkName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getBenchMarkName method, of class BenchMarkVO.
     */
    @Test
    public void testGetBenchMarkName() {
        System.out.println("getBenchMarkName");
        BenchMarkVO instance = new BenchMarkVO();
        String expResult = "BMName2";
        String sBMName = "BMName2";
        instance.setBenchMarkName(sBMName);
        String result = instance.getBenchMarkName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setBenchMarkCode method, of class BenchMarkVO.
     */
    @Test
    public void testSetBenchMarkCode() {
        System.out.println("setBenchMarkCode");
        String iBenchMarkCode = "bm6";
        String expResult = "bm6";
        BenchMarkVO instance = new BenchMarkVO();
        instance.setBenchMarkCode(iBenchMarkCode);
        String result = instance.getBenchMarkCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getBenchMarkCode method, of class BenchMarkVO.
     */
    @Test
    public void testGetBenchMarkCode() {
        System.out.println("getBenchMarkCode");
        BenchMarkVO instance = new BenchMarkVO();
        String expResult = "bm3";
        String sBMCode = "bm3";
        instance.setBenchMarkCode(sBMCode);
        String result = instance.getBenchMarkCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
