/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lonsec.excessreturn.Service;

import com.lonsec.excessreturn.ServiceVO.FundReturnSeriesVO;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Devendra
 */
public class ExcessReturnServiceTest {
    
    public ExcessReturnServiceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of distinctByKey method, of class ExcessReturnService.
     */
    @Test
    public void testDistinctByKey() {
        System.out.println("distinctByKey");
        Function keyExtractor = null;
        Predicate expResult = null;
        Predicate result = ExcessReturnService.distinctByKey(keyExtractor);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of callService method, of class ExcessReturnService.
     */
    @Test
    public void testCallService() {
        System.out.println("callService");
        ExcessReturnService instance = new ExcessReturnService();
        instance.callService();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of printMonthlyOutPerf method, of class ExcessReturnService.
     */
    @Test
    public void testPrintMonthlyOutPerf() {
        System.out.println("printMonthlyOutPerf");
        List lEReturnList = null;
        int i = 0;
        int j = 0;
        ExcessReturnService instance = new ExcessReturnService();
        instance.printMonthlyOutPerf(lEReturnList, i, j);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
